export interface User {
  id: string;
  username: string;
  email: string;
  profile_picture?: string;
  bio?: string;
  favorite_genres: string[];
  favorite_artists: string[];
  subscription_type: 'FREE' | 'PREMIUM';
  subscription_expiry?: string;
  created_at: string;
}

export interface Artist {
  id: string;
  name: string;
  image: string;
  biography: string;
  followers: number;
  isVerified?: boolean;
}

export interface Album {
  id: string;
  title: string;
  cover_image: string;
  artistId: string;
  artistName: string;
  release_date: string;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  artistId: string;
  album: string;
  albumId: string;
  genre: string;
  audio_file: string; // URL to playable audio
  cover_image: string;
  duration: number; // in seconds
  plays: number;
  likes: number;
  upload_date: string;
}

export interface Playlist {
  id: string;
  title: string;
  description: string;
  cover_image: string;
  ownerId: string;
  ownerName: string;
  tracks: string[]; // List of Track IDs
  collaborators: string[]; // List of User IDs
  followers: number;
  isPublic: boolean;
}

export interface Comment {
  id: string;
  userId: string;
  username: string;
  userAvatar?: string;
  trackId: string;
  comment: string;
  created_at: string;
}

export interface ListeningHistory {
  id: string;
  userId: string;
  trackId: string;
  listened_at: string;
}

export interface Notification {
  id: string;
  message: string;
  type: 'social' | 'system' | 'subscription';
  created_at: string;
  read: boolean;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  features: string[];
}
