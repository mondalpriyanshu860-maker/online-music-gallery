import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Search,
  Music,
  Plus,
  Trash2,
  Lock,
  Unlock,
  Sparkles,
  TrendingUp,
  Heart,
  MessageSquare,
  Users,
  Bell,
  Settings,
  ShieldCheck,
  CreditCard,
  ChevronRight,
  Share2,
  LogOut,
  User as UserIcon,
  Activity,
  Layers,
  ChevronUp,
  CheckCircle2,
  Eye,
  Check,
  Disc,
  Clock,
  Send,
  Sparkle
} from 'lucide-react';
import { User, Artist, Album, Track, Playlist, Comment, Notification } from './types';

export default function App() {
  // Auth state
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authView, setAuthView] = useState<'login' | 'register' | 'forgot' | null>(null);
  const [authEmail, setAuthEmail] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authUsername, setAuthUsername] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSuccessMsg, setAuthSuccessMsg] = useState<string | null>(null);

  // App catalog states
  const [tracks, setTracks] = useState<Track[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [selectedArtist, setSelectedArtist] = useState<Artist | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string>('All');
  const [sortBy, setSortBy] = useState<string>('recent');

  // Interactive View States: 'discover' | 'charts' | 'playlists' | 'premium' | 'admin' | 'social'
  const [activeTab, setActiveTab] = useState<'discover' | 'charts' | 'playlists' | 'premium' | 'admin' | 'social'>('discover');

  // Playback Player engine
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolume] = useState<number>(80);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [playbackQueue, setPlaybackQueue] = useState<Track[]>([]);
  const [currentQueueIndex, setCurrentQueueIndex] = useState<number>(-1);
  const [isShuffle, setIsShuffle] = useState<boolean>(false);
  const [isRepeat, setIsRepeat] = useState<boolean>(false);

  // Equalizer visualizer properties
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const visualizerTimerRef = useRef<number | null>(null);

  // Recommendations state
  const [aiRecommendations, setAiRecommendations] = useState<Track[]>([]);
  const [aiCommentary, setAiCommentary] = useState<string>('');

  // Comment engagement State
  const [trackComments, setTrackComments] = useState<Comment[]>([]);
  const [newCommentText, setNewCommentText] = useState('');
  const [likedTrackIds, setLikedTrackIds] = useState<string[]>([]);

  // Playlist builders
  const [selectedPlaylist, setSelectedPlaylist] = useState<Playlist | null>(null);
  const [newPlaylistTitle, setNewPlaylistTitle] = useState('');
  const [newPlaylistDesc, setNewPlaylistDesc] = useState('');
  const [inviteUserId, setInviteUserId] = useState('');

  // Admin dashboard metrics
  const [adminAnalytics, setAdminAnalytics] = useState<any>(null);
  const [adminNewSong, setAdminNewSong] = useState({
    title: '',
    artist: '',
    genre: 'Synthwave',
    audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',
    cover_image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=400',
    duration: 250,
    album: 'Single'
  });

  // Premium Billing Simulation
  const [couponCode, setCouponCode] = useState('');
  const [couponAppliedCode, setCouponAppliedCode] = useState('');
  const [couponDiscount, setCouponDiscount] = useState<number>(0);
  const [billingStatus, setBillingStatus] = useState<string | null>(null);

  // Fetch initial system items
  useEffect(() => {
    fetchTracks();
    fetchPlaylists();
    fetchArtists();
    if (token) {
      fetchCurrentUser();
      fetchNotifications();
      fetchLikedTracks();
    }
  }, [token]);

  // Fetch Recommendations & AI Commentary
  useEffect(() => {
    fetchRecommendations();
  }, [currentUser, tracks]);

  // Handle HTML5 Audio Player events
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    const audio = audioRef.current;

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const onLoadedMetadata = () => {
      setDuration(audio.duration || 0);
    };

    const onEnded = () => {
      handleNextTrack();
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('ended', onEnded);

    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('ended', onEnded);
    };
  }, [playbackQueue, currentQueueIndex, isRepeat]);

  // Sync play states
  useEffect(() => {
    if (!audioRef.current) return;
    if (currentTrack) {
      if (audioRef.current.src !== currentTrack.audio_file) {
        audioRef.current.src = currentTrack.audio_file;
        // Notify backend of listen registration
        fetch(`/api/tracks/${currentTrack.id}/listen`, {
          method: 'POST',
          headers: token ? { 'Authorization': `Bearer ${token}` } : {}
        });
      }

      if (isPlaying) {
        audioRef.current.play().catch(e => console.warn("Audio playback gesture warning:", e));
      } else {
        audioRef.current.pause();
      }
    }
  }, [currentTrack, isPlaying]);

  // Volume synchronization
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume / 100;
    }
  }, [volume, isMuted]);

  // High Fidelity programmatically animated Canvas Visualizer (safe for cross-origin audio sources in sandbox!)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrame: number;
    let phase = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const barCount = 35;
      const spacing = 3;
      const barWidth = (canvas.width - spacing * (barCount - 1)) / barCount;

      phase += isPlaying ? 0.08 : 0.01;

      for (let i = 0; i < barCount; i++) {
        // Calculate dynamic wave amplitude
        const multiplier = isPlaying ? (0.3 + Math.sin(phase + i * 0.4) * 0.7) : 0.1;
        // Generate a geometric mountain curve
        const centerOffset = Math.sin((i / barCount) * Math.PI);
        const barHeight = Math.max(3, multiplier * centerOffset * canvas.height * 0.95);

        // Neon violet to electric cyan gradient paint style
        const grad = ctx.createLinearGradient(0, canvas.height, 0, canvas.height - barHeight);
        grad.addColorStop(0, 'rgba(147, 51, 234, 0.2)');   // Violet transp
        grad.addColorStop(0.5, '#9333ea');                 // Violet core
        grad.addColorStop(1, '#06b6d4');                   // Cyan highlight

        ctx.fillStyle = grad;
        ctx.fillRect(i * (barWidth + spacing), canvas.height - barHeight, barWidth, barHeight);
      }

      animFrame = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animFrame);
    };
  }, [isPlaying]);

  // Real-time notification trigger generator helper
  const triggerNotification = (message: string, type: 'social' | 'system' | 'subscription') => {
    const newNotif: Notification = {
      id: Math.random().toString(),
      message,
      type,
      read: false,
      created_at: new Date().toISOString()
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  // API wrappers
  const fetchTracks = async () => {
    try {
      const q = new URLSearchParams({
        search: searchQuery,
        sort: sortBy
      });
      if (selectedGenre !== 'All') {
        q.append('genre', selectedGenre);
      }
      const res = await fetch(`/api/tracks?${q.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setTracks(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchPlaylists = async () => {
    try {
      const res = await fetch('/api/playlists');
      if (res.ok) {
        const data = await res.json();
        setPlaylists(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchArtists = async () => {
    try {
      const res = await fetch('/api/artists');
      if (res.ok) {
        const data = await res.json();
        setArtists(data);
        if (data.length > 0) {
          setSelectedArtist(data[0]);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchCurrentUser = async () => {
    try {
      const res = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
      } else {
        handleLogout();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchNotifications = async () => {
    try {
      const res = await fetch('/api/notifications', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchLikedTracks = async () => {
    try {
      const res = await fetch('/api/likes', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setLikedTrackIds(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchRecommendations = async () => {
    try {
      const headers: any = {};
      if (token) headers['Authorization'] = `Bearer ${token}`;
      const res = await fetch('/api/recommendations', { headers });
      if (res.ok) {
        const data = await res.json();
        setAiRecommendations(data.recommendations || []);
        setAiCommentary(data.aiCommentary || '');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchComments = async (trackId: string) => {
    try {
      const res = await fetch(`/api/comments?trackId=${trackId}`);
      if (res.ok) {
        const data = await res.json();
        setTrackComments(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchAdminAnalytics = async () => {
    try {
      const res = await fetch('/api/admin/analytics');
      if (res.ok) {
        const data = await res.json();
        setAdminAnalytics(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // User Actions
  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMsg(null);

    const endpoint = authView === 'login' ? '/api/auth/login' : '/api/auth/register';
    const body: any = { email: authEmail, password: authPassword };
    if (authView === 'register') {
      body.username = authUsername;
    }

    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('token', data.token);
        setToken(data.token);
        setCurrentUser(data.user);
        setAuthView(null);
        triggerNotification(`Welcome back, ${data.user.username}!`, 'system');
      } else {
        setAuthError(data.error || 'Authentication sequence failed.');
      }
    } catch (err) {
      setAuthError('Network communication error.');
    }
  };

  const handleOAuthSimulate = async (provider: 'Google' | 'Facebook') => {
    try {
      const email = `${provider.toLowerCase()}_user${Math.floor(Math.random() * 1000)}@test.com`;
      const name = `${provider} Star Maker`;
      const res = await fetch('/api/auth/oauth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ provider, email, name })
      });
      if (res.ok) {
        const data = await res.json();
        localStorage.setItem('token', data.token);
        setToken(data.token);
        setCurrentUser(data.user);
        setAuthView(null);
        triggerNotification(`Connected successfully with ${provider}!`, 'social');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: authEmail })
      });
      const data = await res.json();
      if (res.ok) {
        setAuthSuccessMsg(`Simulated Password Reset sent code successfully! Code: ${data.code}`);
      } else {
        setAuthError(data.error);
      }
    } catch (err) {
      setAuthError('Failed to call password reset endpoint.');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setCurrentUser(null);
    setLikedTrackIds([]);
    setSelectedPlaylist(null);
    triggerNotification('Logged out from Online Music Gallery session.', 'system');
  };

  const handleToggleLike = async (trackId: string) => {
    if (!token) {
      setAuthView('login');
      return;
    }
    try {
      const res = await fetch('/api/likes/toggle', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ trackId })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.liked) {
          setLikedTrackIds(prev => [...prev, trackId]);
          triggerNotification(`Liked song! Added to your recommendation profiles.`, 'social');
        } else {
          setLikedTrackIds(prev => prev.filter(id => id !== trackId));
        }
        // Refresh catalog lists to display verified like offsets
        fetchTracks();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubscribe = async (plan: string, gateway: 'Razorpay' | 'Stripe') => {
    if (!token) {
      setAuthView('login');
      return;
    }
    setBillingStatus('processing');
    try {
      const res = await fetch('/api/subscriptions/purchase', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          planName: plan,
          couponApplied: couponAppliedCode || undefined,
          paymentGateway: gateway
        })
      });
      if (res.ok) {
        const data = await res.json();
        setBillingStatus('success');
        fetchCurrentUser();
        setTimeout(() => setBillingStatus(null), 3000);
      } else {
        setBillingStatus('failed');
      }
    } catch (err) {
      setBillingStatus('failed');
    }
  };

  const handleActiveTrial = async () => {
    if (!token) {
      setAuthView('login');
      return;
    }
    try {
      const res = await fetch('/api/subscriptions/trial', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        fetchCurrentUser();
        triggerNotification('Started active 7-Day FREE premium trial!', 'subscription');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCancelSubscription = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/subscriptions/cancel', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        fetchCurrentUser();
        triggerNotification('Downgraded to limited free subscription mode.', 'subscription');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const applyCoupon = async () => {
    try {
      const res = await fetch('/api/subscriptions/apply-coupon', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: couponCode })
      });
      const data = await res.json();
      if (res.ok) {
        setCouponAppliedCode(data.code);
        setCouponDiscount(data.discount);
        triggerNotification(`Applied promotional code! ${data.discount}% OFF subscription.`, 'subscription');
      } else {
        alert(data.error);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Comment action
  const handleAddComment = async (e: React.FormEvent, trackId: string) => {
    e.preventDefault();
    if (!token) {
      setAuthView('login');
      return;
    }
    if (!newCommentText.trim()) return;

    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ trackId, comment: newCommentText })
      });
      if (res.ok) {
        setNewCommentText('');
        fetchComments(trackId);
        triggerNotification(`Comment posted successfully!`, 'social');
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Playlist management
  const handleCreatePlaylist = async () => {
    if (!token) {
      setAuthView('login');
      return;
    }
    if (!newPlaylistTitle.trim()) return;

    try {
      const res = await fetch('/api/playlists', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ title: newPlaylistTitle, description: newPlaylistDesc })
      });
      if (res.ok) {
        setNewPlaylistTitle('');
        setNewPlaylistDesc('');
        fetchPlaylists();
        triggerNotification('Interactive Playlist created successfully!', 'system');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeletePlaylist = async (id: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/playlists/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        setSelectedPlaylist(null);
        fetchPlaylists();
        triggerNotification('Playlist deleted.', 'system');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddTrackToPlaylist = async (playlistId: string, trackId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/playlists/${playlistId}/add-track`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ trackId })
      });
      if (res.ok) {
        const data = await res.json();
        // Update selection
        setSelectedPlaylist(data);
        fetchPlaylists();
        triggerNotification('Added track to selected playlist!', 'system');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRemoveTrackFromPlaylist = async (playlistId: string, trackId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/playlists/${playlistId}/remove-track`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ trackId })
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedPlaylist(data);
        fetchPlaylists();
        triggerNotification('Removed track from playlist.', 'system');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleInviteToCollaborate = async (playlistId: string) => {
    if (!token || !inviteUserId.trim()) return;
    // Push simulated collaborator to playlist
    if (!selectedPlaylist) return;
    const collaborators = [...selectedPlaylist.collaborators, inviteUserId];
    try {
      const res = await fetch(`/api/playlists/${playlistId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ collaborators })
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedPlaylist(data);
        setInviteUserId('');
        triggerNotification(`Invited collaborator ${inviteUserId} successfully!`, 'social');
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Music Player Core Handlers
  const handlePlayTrack = (track: Track, currentContextList: Track[] = []) => {
    setCurrentTrack(track);
    setIsPlaying(true);

    if (currentContextList && currentContextList.length > 0) {
      setPlaybackQueue(currentContextList);
      const index = currentContextList.findIndex(t => t.id === track.id);
      setCurrentQueueIndex(index >= 0 ? index : 0);
    } else {
      // Just set queue to contain single track if no context
      if (playbackQueue.length === 0 || !playbackQueue.some(t => t.id === track.id)) {
        setPlaybackQueue([track]);
        setCurrentQueueIndex(0);
      }
    }
    fetchComments(track.id);
  };

  const handleTogglePlay = () => {
    if (!currentTrack && tracks.length > 0) {
      handlePlayTrack(tracks[0], tracks);
      return;
    }
    setIsPlaying(!isPlaying);
  };

  const handleNextTrack = () => {
    if (playbackQueue.length === 0) return;
    let nextIndex = currentQueueIndex + 1;

    if (isShuffle) {
      nextIndex = Math.floor(Math.random() * playbackQueue.length);
    } else if (nextIndex >= playbackQueue.length) {
      nextIndex = isRepeat ? 0 : -1;
    }

    if (nextIndex >= 0 && nextIndex < playbackQueue.length) {
      setCurrentQueueIndex(nextIndex);
      setCurrentTrack(playbackQueue[nextIndex]);
      fetchComments(playbackQueue[nextIndex].id);
    } else {
      setIsPlaying(false);
    }
  };

  const handlePrevTrack = () => {
    if (playbackQueue.length === 0) return;
    let prevIndex = currentQueueIndex - 1;

    if (prevIndex < 0) {
      prevIndex = isRepeat ? playbackQueue.length - 1 : 0;
    }

    setCurrentQueueIndex(prevIndex);
    setCurrentTrack(playbackQueue[prevIndex]);
    fetchComments(playbackQueue[prevIndex].id);
  };

  const formatTime = (timeInSecs: number) => {
    if (isNaN(timeInSecs)) return "0:00";
    const mins = Math.floor(timeInSecs / 60);
    const secs = Math.floor(timeInSecs % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleProgressBarClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!audioRef.current || duration === 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = clickX / rect.width;
    audioRef.current.currentTime = percentage * duration;
    setCurrentTime(percentage * duration);
  };

  // DRM Simulator layer for Premium Offline playback downloading support
  const handleDownloadTrackSecret = (track: Track) => {
    if (!currentUser || currentUser.subscription_type !== 'PREMIUM') {
      triggerNotification('Downloading requires an active Music VIP subscription.', 'subscription');
      setActiveTab('premium');
      return;
    }

    // High fidelity DRM file container trigger simulation
    const bytes = new Blob([JSON.stringify({
      drm_lock: "0xFF-VERIFIED-NODE",
      issued_to: currentUser.email,
      track_id: track.id,
      title: track.title,
      payload_audio: track.audio_file
    })], { type: "application/octet-stream" });

    const link = document.createElement('a');
    link.href = URL.createObjectURL(bytes);
    link.download = `${track.title.toLowerCase().replace(/\s+/g, "_")}_premium_drm.sonx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    triggerNotification(`Offline DRM verified decrypt fully complete. Downloaded: ${track.title}`, 'system');
  };

  // Admin Create song trigger helper
  const handleAdminCreateSong = async () => {
    try {
      const res = await fetch('/api/tracks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(adminNewSong)
      });
      if (res.ok) {
        setAdminNewSong({
          title: '',
          artist: '',
          genre: 'Synthwave',
          audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3',
          cover_image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=400',
          duration: 250,
          album: 'Single'
        });
        fetchTracks();
        fetchAdminAnalytics();
        triggerNotification(`New track '${adminNewSong.title}' updated successfully.`, 'system');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateProfile = async (updates: any) => {
    if (!token) return;
    try {
      const res = await fetch('/api/users/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(updates)
      });
      if (res.ok) {
        const data = await res.json();
        setCurrentUser(data.user);
        triggerNotification('Profile preferences updated!', 'system');
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Load analytics when admin tab chosen
  useEffect(() => {
    if (activeTab === 'admin') {
      fetchAdminAnalytics();
    }
  }, [activeTab]);

  // Handle Search Input Change
  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      fetchTracks();
    }, 250);
    return () => clearTimeout(delayDebounce);
  }, [searchQuery, selectedGenre, sortBy]);

  return (
    <div id="online-music-gallery-container" className="h-screen w-screen bg-[#030014] text-white font-sans flex flex-col overflow-hidden relative select-none">
      {/* Background Ambient Glows */}
      <div className="absolute top-[-150px] left-[-150px] w-[600px] h-[600px] bg-purple-900/10 rounded-full blur-[160px] pointer-events-none"></div>
      <div className="absolute bottom-[-150px] right-[-150px] w-[600px] h-[600px] bg-blue-900/10 rounded-full blur-[160px] pointer-events-none"></div>

      {/* Primary Layout Block */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* SIDEBAR NAVIGATION */}
        <aside id="main-navigation-sidebar" className="w-64 bg-black/40 backdrop-blur-2xl border-r border-white/5 flex flex-col z-10 shrink-0">
          <div className="p-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Disc className="w-6 h-6 text-white animate-spin-slow" />
            </div>
            <div>
              <span className="text-lg font-black tracking-wider bg-gradient-to-r from-white to-purple-400 bg-clip-text text-transparent">SONICX</span>
              <p className="text-[10px] text-gray-400 tracking-widest uppercase">Music Engine</p>
            </div>
          </div>
          
          <nav className="flex-1 px-4 space-y-1 overflow-y-auto">
            <div className="text-xs font-semibold text-gray-500 uppercase tracking-widest px-4 mb-3 mt-4">Main Menu</div>
            
            <button
              onClick={() => { setActiveTab('discover'); setSelectedPlaylist(null); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-sm transition-all duration-300 ${
                activeTab === 'discover' && !selectedPlaylist
                  ? 'bg-gradient-to-r from-purple-900/40 to-blue-950/40 border-purple-500/30 text-white font-semibold'
                  : 'border-transparent text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Sparkles className="w-5 h-5 text-purple-400" />
              <span>Discover & AI</span>
            </button>

            <button
              onClick={() => { setActiveTab('charts'); setSelectedPlaylist(null); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-sm transition-all duration-300 ${
                activeTab === 'charts'
                  ? 'bg-gradient-to-r from-purple-900/40 to-blue-950/40 border-purple-500/30 text-white font-semibold'
                  : 'border-transparent text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <TrendingUp className="w-5 h-5 text-purple-400" />
              <span>Top Charts</span>
            </button>

            <button
              onClick={() => { setActiveTab('playlists'); setSelectedPlaylist(null); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-sm transition-all duration-300 ${
                activeTab === 'playlists' && !selectedPlaylist
                  ? 'bg-gradient-to-r from-purple-900/40 to-blue-950/40 border-purple-500/30 text-white font-semibold'
                  : 'border-transparent text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Layers className="w-5 h-5 text-purple-400" />
              <span>Playlists Hub</span>
            </button>

            <button
              onClick={() => { setActiveTab('social'); setSelectedPlaylist(null); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-sm transition-all duration-300 ${
                activeTab === 'social'
                  ? 'bg-gradient-to-r from-purple-900/40 to-blue-950/40 border-purple-500/30 text-white font-semibold'
                  : 'border-transparent text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Users className="w-5 h-5 text-purple-400" />
              <span>Social Feed</span>
            </button>

            <button
              onClick={() => { setActiveTab('premium'); setSelectedPlaylist(null); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-sm transition-all duration-300 ${
                activeTab === 'premium'
                  ? 'bg-gradient-to-r from-purple-900/40 to-blue-950/40 border-purple-500/30 text-white font-semibold'
                  : 'border-transparent text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <CreditCard className="w-5 h-5 text-purple-400" />
              <span>Music VIP</span>
            </button>

            <button
              onClick={() => { setActiveTab('admin'); setSelectedPlaylist(null); }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-sm transition-all duration-300 ${
                activeTab === 'admin'
                  ? 'bg-gradient-to-r from-purple-900/40 to-blue-950/40 border-purple-500/30 text-white font-semibold'
                  : 'border-transparent text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Activity className="w-5 h-5 text-purple-400" />
              <span>Catalog Admin</span>
            </button>

            {/* Simulated Live Playlists Section */}
            <div className="text-xs font-semibold text-gray-500 uppercase tracking-widest px-4 mb-3 mt-8">Dynamic Playlists</div>
            <div className="space-y-1">
              {playlists.map((p, index) => (
                <button
                  key={p.id}
                  onClick={() => { setSelectedPlaylist(p); setActiveTab('playlists'); }}
                  className={`w-full flex items-center gap-3 px-4 py-2 text-left text-sm transition-colors rounded-lg ${
                    selectedPlaylist?.id === p.id
                      ? 'bg-white/10 text-white'
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <div className={`w-2 h-2 rounded-full ${index % 2 === 0 ? 'bg-purple-500' : 'bg-blue-400'}`} />
                  <span className="truncate">{p.title}</span>
                </button>
              ))}
            </div>
          </nav>
          
          {/* VIP Upgrade Pitch */}
          <div className="p-4 mx-2 my-4 bg-gradient-to-br from-purple-900/30 to-blue-900/30 border border-purple-500/20 rounded-2xl">
            <div className="flex items-center gap-1.5 mb-1">
              <Sparkle className="w-4 h-4 text-purple-400 fill-current" />
              <p className="text-[11px] font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-300 uppercase">Music VIP Access</p>
            </div>
            <p className="text-[10px] text-gray-400 leading-relaxed mb-3">Hi-Res Lossless Audio, offline DRM downloads & direct AI smart prompts.</p>
            {currentUser?.subscription_type === 'PREMIUM' ? (
              <div className="w-full text-center py-1.5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg text-[10px] font-bold">Verified Premium ✔</div>
            ) : (
              <button
                onClick={() => setActiveTab('premium')}
                className="w-full py-1.5 bg-white text-black hover:bg-purple-100 text-[10px] font-black rounded-lg transition-transform hover:scale-[1.03]"
              >
                Upgrade Plan
              </button>
            )}
          </div>
        </aside>

        {/* MAIN BODY WINDOW */}
        <main className="flex-1 flex flex-col z-10 relative overflow-hidden">
          
          {/* HEADER ROW */}
          <header className="h-20 px-8 flex items-center justify-between bg-black/10 backdrop-blur-md border-b border-white/5 shrink-0">
            {/* Real Search Box */}
            <div className="flex items-center gap-4 bg-white/5 border border-white/5 hover:border-white/10 rounded-full px-5 py-2 w-96 transition-all">
              <Search className="w-4 h-4 text-gray-400 shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search songs, artists, genres..."
                className="bg-transparent border-none text-xs focus:outline-none text-gray-300 w-full"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="text-gray-500 hover:text-white text-xs">Clear</button>
              )}
            </div>

            {/* Profile Sign-in & Trigger details */}
            <div className="flex items-center gap-6">
              
              {/* Notification Center */}
              <div className="relative group">
                <button className="p-2 text-gray-400 hover:text-white transition-colors relative">
                  <Bell className="w-5 h-5" />
                  {notifications.some(n => !n.read) && (
                    <span className="absolute top-1 right-1.5 w-2 h-2 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full"></span>
                  )}
                </button>
                
                {/* Notification Dropdown hover list */}
                <div className="absolute right-0 top-10 w-80 bg-[#09051d] border border-white/10 rounded-2xl shadow-2xl p-4 hidden group-hover:block z-50 animate-fade-in">
                  <div className="flex justify-between items-center mb-3">
                    <p className="text-xs font-bold tracking-tight">System Intel Feed</p>
                    <button
                      onClick={async () => {
                        if (token) {
                          await fetch('/api/notifications/clear', { method: 'POST', headers: { 'Authorization': `Bearer ${token}` } });
                          fetchNotifications();
                        }
                      }}
                      className="text-[10px] text-purple-400 hover:underline hover:text-purple-300"
                    >
                      Clear All
                    </button>
                  </div>
                  <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar">
                    {notifications.length === 0 ? (
                      <p className="text-[11px] text-gray-500 text-center py-4">No recent intelligence messages.</p>
                    ) : (
                      notifications.slice(0, 8).map(n => (
                        <div key={n.id} className="p-2.5 bg-white/5 rounded-lg border border-white/5 text-[11px]">
                          <div className="flex items-center justify-between mb-1">
                            <span className={`text-[9px] uppercase font-bold px-1.5 py-0.5 rounded ${
                              n.type === 'subscription' ? 'bg-purple-900/60 text-purple-300' : 'bg-blue-900/60 text-blue-300'
                            }`}>{n.type}</span>
                            <span className="text-[9px] text-gray-500">{new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                          <p className="text-gray-300 leading-normal">{n.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* User Identity widget */}
              {currentUser ? (
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="text-xs font-bold tracking-tight text-white">{currentUser.username}</p>
                    <span className={`text-[10px] font-bold tracking-tight ${
                      currentUser.subscription_type === 'PREMIUM' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'bg-gray-500/20 text-gray-400'
                    } px-2 py-0.5 rounded-full inline-block mt-0.5`}>
                      {currentUser.subscription_type}
                    </span>
                  </div>
                  <div className="relative group">
                    <img
                      src={currentUser.profile_picture || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${currentUser.username}`}
                      alt="avatar"
                      className="w-10 h-10 rounded-xl border border-white/10 hover:border-purple-500 cursor-pointer object-cover transition-colors"
                    />
                    
                    {/* Hover profile popup menu */}
                    <div className="absolute right-0 top-11 w-48 bg-[#09051d] border border-white/10 rounded-xl shadow-2xl p-2 hidden group-hover:block z-50">
                      <button
                        onClick={() => handleLogout()}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs text-rose-400 hover:bg-white/5 rounded-lg transition-colors text-left"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setAuthView('login')}
                  className="px-5 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-xs font-bold rounded-full shadow-lg shadow-purple-500/20 hover:scale-[1.03] transition-transform flex items-center gap-2"
                >
                  <UserIcon className="w-4 h-4" />
                  <span>Connect Profile</span>
                </button>
              )}

            </div>
          </header>

          {/* APP SCROLLABLE HERO & GRID GRIDVIEW */}
          <div className="flex-1 p-8 overflow-y-auto custom-scrollbar">
            
            {/* HERO PROMOTIONAL SECTION (Only shown in Discover dashboard) */}
            {activeTab === 'discover' && !selectedPlaylist && (
              <div className="relative rounded-[32px] h-64 overflow-hidden mb-10 group shadow-2xl border border-white/5">
                <div className="absolute inset-0 bg-gradient-to-r from-black via-black/50 to-transparent z-10"></div>
                <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?auto=format&fit=crop&w=1200')] bg-cover bg-center group-hover:scale-105 transition-transform duration-1000"></div>
                
                {/* Moving background glowing neon particle points */}
                <div className="absolute inset-0 z-20 pointer-events-none overflow-hidden">
                  <div className="absolute w-2 h-2 bg-purple-500 rounded-full top-1/4 left-1/3 animate-ping opacity-60"></div>
                  <div className="absolute w-3 h-3 bg-blue-400 rounded-full top-1/2 left-2/3 animate-pulse opacity-40"></div>
                  <div className="absolute w-1.5 h-1.5 bg-pink-500 rounded-full bottom-1/3 left-1/4 animate-ping opacity-50"></div>
                </div>

                <div className="relative z-30 h-full flex flex-col justify-center px-10 max-w-lg">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="px-2.5 py-0.5 bg-gradient-to-r from-purple-600 to-blue-600 text-[9px] font-black tracking-widest uppercase rounded-full">NEW HORIZONS</span>
                    {currentUser?.subscription_type === 'PREMIUM' && <span className="text-[10px] text-purple-300 font-bold flex items-center gap-1"><Sparkles className="w-3 h-3" /> Hi-Res Audiophile On</span>}
                  </div>
                  <h1 className="text-4xl font-extrabold mb-3 leading-tight tracking-tight text-white drop-shadow">
                    ORBITAL PULSES
                  </h1>
                  <p className="text-xs text-gray-300 mb-5 leading-relaxed">
                    Slam the throttle forward on synthetic resonance. Designed in Tokyo.
                  </p>
                  <div className="flex gap-3">
                    <button
                      onClick={() => tracks.length > 0 && handlePlayTrack(tracks[0], tracks)}
                      className="px-6 py-2.5 bg-white text-black text-xs font-bold rounded-full hover:scale-105 transition-transform flex items-center gap-1.5 shadow"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      Play Broadcast
                    </button>
                    <button
                      onClick={() => setActiveTab('premium')}
                      className="px-6 py-2.5 bg-white/10 backdrop-blur-md border border-white/10 text-xs font-bold rounded-full hover:bg-white/20 transition-colors"
                    >
                      Browse VIP Plans
                    </button>
                  </div>
                </div>
              </div>
            )}


            {/* DISCOVER VIEW PANEL */}
            {activeTab === 'discover' && !selectedPlaylist && (
              <div className="space-y-10">
                
                {/* AI RECON BOX SECTION */}
                <div className="bg-gradient-to-br from-purple-955/40 to-black/60 border border-purple-500/20 rounded-3xl p-6 relative">
                  <div className="absolute top-4 right-4 text-purple-400">
                    <Sparkles className="w-6 h-6 animate-pulse" />
                  </div>
                  <h3 className="text-lg font-bold tracking-tight mb-1 flex items-center gap-2 text-white">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    AI Intelligence Listening recommendations
                  </h3>
                  <p className="text-[11px] text-purple-300 italic mb-4 max-w-xl">
                    "{aiCommentary || 'Processing your music DNA... Connecting with Gemini server node.'}"
                  </p>

                  <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                    {aiRecommendations.length === 0 ? (
                      <div className="col-span-full py-6 text-center text-xs text-gray-500">
                        Gathering data metrics. Interact with tracks to seed AI vectors.
                      </div>
                    ) : (
                      aiRecommendations.map(track => (
                        <div
                          key={`rec-${track.id}`}
                          onClick={() => handlePlayTrack(track, aiRecommendations)}
                          className="bg-white/5 border border-white/5 rounded-2xl p-3 hover:bg-white/10 cursor-pointer transition-all duration-300 group relative"
                        >
                          <div className="aspect-square rounded-xl overflow-hidden mb-3 relative">
                            <img src={track.cover_image} alt={track.title} className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300" />
                            <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                              <Play className="w-8 h-8 text-white fill-current" />
                            </div>
                          </div>
                          <p className="text-xs font-bold truncate">{track.title}</p>
                          <p className="text-[10px] text-gray-400 truncate mt-0.5">{track.artist}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* GENRE SELECTOR RAIL */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-sm font-bold tracking-widest text-purple-400 uppercase">Browse Genres</h4>
                  </div>
                  <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
                    {['All', 'Synthwave', 'Ambient', 'Lofi Hip Hop', 'Cyberpunk', 'Techno'].map(g => (
                      <button
                        key={g}
                        onClick={() => setSelectedGenre(g)}
                        className={`px-4 py-2 rounded-full text-xs font-bold transition-all border shrink-0 ${
                          selectedGenre === g
                            ? 'bg-purple-600 border-purple-500 text-white shadow-lg shadow-purple-500/10 scale-103'
                            : 'bg-white/5 border-white/5 text-gray-400 hover:text-white hover:bg-white/10'
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                </div>

                {/* TRACK GRID */}
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <h2 className="text-xl font-bold tracking-tight">Vibe Grid Tracks</h2>
                      <p className="text-xs text-gray-400 mt-1">Direct from independent neon artists</p>
                    </div>
                    <div className="flex gap-2">
                      <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value)}
                        className="bg-white/5 border border-white/5 hover:border-white/10 text-xs font-bold px-3 py-1.5 rounded-xl block cursor-pointer text-gray-300 focus:outline-none"
                      >
                        <option value="recent">Recently Uploaded</option>
                        <option value="plays">Most Played</option>
                        <option value="likes">Most Liked</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
                    {tracks.length === 0 ? (
                      <div className="col-span-full py-10 text-center text-xs text-gray-500">
                        No songs registered matching current query.
                      </div>
                    ) : (
                      tracks.map(track => (
                        <div
                          key={track.id}
                          className="bg-white/5 border border-white/5 rounded-3xl p-4 hover:bg-white/10 hover:border-purple-500/20 transition-all duration-300 group flex flex-col justify-between"
                        >
                          <div>
                            <div className="aspect-square rounded-2xl overflow-hidden mb-3 relative bg-zinc-900 shadow-inner">
                              <img src={track.cover_image} alt={track.title} className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500" />
                              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                                <button
                                  onClick={(e) => { e.stopPropagation(); handlePlayTrack(track, tracks); }}
                                  className="w-12 h-12 bg-white text-black hover:scale-110 rounded-full flex items-center justify-center transition-all shadow-lg"
                                >
                                  <Play className="w-5 h-5 fill-current ml-0.5" />
                                </button>
                                <button
                                  onClick={(e) => { e.stopPropagation(); handleDownloadTrackSecret(track); }}
                                  className="w-10 h-10 bg-black/60 text-white hover:scale-110 hover:bg-black/90 rounded-full flex items-center justify-center transition-all"
                                  title="Download Offline DRM"
                                >
                                  <ChevronUp className="w-5 h-5 rotate-180" />
                                </button>
                              </div>
                            </div>
                            <h3 className="font-bold text-xs truncate text-gray-100">{track.title}</h3>
                            <p className="text-[10px] text-purple-400 mt-1 hover:underline cursor-pointer truncate">{track.artist}</p>
                          </div>

                          <div className="flex items-center justify-between mt-4 border-t border-white/5 pt-3">
                            <span className="text-[9px] text-gray-500 tracking-wider uppercase bg-white/5 px-2 py-0.5 rounded">{track.genre}</span>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleToggleLike(track.id)}
                                className={`text-gray-400 hover:text-rose-500 transition-colors ${likedTrackIds.includes(track.id) ? 'text-rose-500' : ''}`}
                              >
                                <Heart className={`w-3.5 h-3.5 ${likedTrackIds.includes(track.id) ? 'fill-current' : ''}`} />
                              </button>
                              <span className="text-[10px] text-gray-500">{track.likes}</span>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* ARTISTS PROFILE CIRCLES */}
                <div className="mt-6">
                  <h3 className="text-sm font-bold tracking-widest text-purple-500 uppercase mb-4">Trending Creators</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {artists.map(art => (
                      <div
                        key={art.id}
                        className="p-4 bg-white/5 border border-white/5 rounded-2xl flex items-center gap-4 hover:bg-white/10 hover:border-purple-500/10 cursor-pointer transition-colors"
                      >
                        <img src={art.image} alt={art.name} className="w-12 h-12 rounded-full object-cover border border-white/10" />
                        <div className="overflow-hidden">
                          <p className="text-xs font-bold text-white truncate">{art.name}</p>
                          <p className="text-[10px] text-gray-400 mt-0.5 truncate">{art.followers.toLocaleString()} Followers</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}


            {/* CHARTS VIEW PANEL */}
            {activeTab === 'charts' && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl font-black tracking-tight text-white mb-1">SonicX Global Charts</h2>
                  <p className="text-xs text-gray-400">The most popular transmissions updated live across network nodes.</p>
                </div>

                <div className="bg-white/5 border border-white/5 rounded-3xl overflow-hidden shadow-2xl">
                  <div className="px-6 py-4 bg-white/5 border-b border-white/5 flex items-center justify-between">
                    <span className="text-xs text-gray-400 font-bold">Track Name</span>
                    <div className="flex gap-8 text-xs text-gray-400 font-bold pr-10">
                      <span>Stream Plays</span>
                      <span>Likes count</span>
                      <span>Duration</span>
                    </div>
                  </div>

                  <div className="divide-y divide-white/5">
                    {[...tracks].sort((a,b) => b.plays - a.plays).map((track, i) => (
                      <div
                        key={`chart-${track.id}`}
                        onClick={() => handlePlayTrack(track, tracks)}
                        className="px-6 py-4 hover:bg-white/10 transition-colors flex items-center justify-between cursor-pointer group"
                      >
                        <div className="flex items-center gap-4 overflow-hidden">
                          <span className="text-sm font-bold text-gray-500 w-4 pl-1">{i + 1}</span>
                          <img src={track.cover_image} alt={track.title} className="w-10 h-10 rounded-lg object-cover" />
                          <div>
                            <p className="text-xs font-bold text-white truncate">{track.title}</p>
                            <p className="text-[10px] text-purple-400 truncate mt-0.5">{track.artist}</p>
                          </div>
                        </div>

                        <div className="flex gap-12 text-xs text-gray-300 pr-10 items-center justify-end">
                          <span className="w-20 text-right">{track.plays.toLocaleString()}</span>
                          <span className="w-16 text-right text-rose-400 font-semibold">{track.likes}</span>
                          <span className="w-12 text-right text-gray-500">{formatTime(track.duration)}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}


            {/* PLAYLISTS HUB VIEW */}
            {activeTab === 'playlists' && (
              <div>
                {!selectedPlaylist ? (
                  <div>
                    <h2 className="text-2xl font-black tracking-tight mb-2">Saved Playlists & Station Hub</h2>
                    <p className="text-xs text-gray-400 mb-8">Create collaborative music packages with multiple community editors.</p>

                    {/* Create Playlist Modal Box */}
                    <div className="bg-gradient-to-br from-purple-950/20 to-blue-950/20 border border-purple-500/20 p-6 rounded-3xl mb-10">
                      <h3 className="text-xs uppercase font-black tracking-widest text-purple-400 mb-4">Establish New Station</h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        <input
                          type="text"
                          value={newPlaylistTitle}
                          onChange={(e) => setNewPlaylistTitle(e.target.value)}
                          placeholder="Station Title (e.g., Cybernetic Study loops)"
                          className="bg-white/5 border border-white/10 focus:border-purple-500 text-xs rounded-xl px-4 py-3 placeholder-gray-500 focus:outline-none"
                        />
                        <input
                          type="text"
                          value={newPlaylistDesc}
                          onChange={(e) => setNewPlaylistDesc(e.target.value)}
                          placeholder="Description / Station Mission"
                          className="bg-white/5 border border-white/10 focus:border-purple-500 text-xs rounded-xl px-4 py-3 placeholder-gray-500 focus:outline-none"
                        />
                      </div>
                      <button
                        onClick={handleCreatePlaylist}
                        className="mt-4 px-6 py-2.5 bg-gradient-to-r from-purple-600 to-blue-600 text-xs font-bold rounded-xl hover:scale-[1.02] transition-transform flex items-center gap-1.5"
                      >
                        <Plus className="w-4 h-4" />
                        Deploy Playlist Configuration
                      </button>
                    </div>

                    <div className="grid md:grid-cols-3 gap-6">
                      {playlists.map(p => (
                        <div
                          key={p.id}
                          className="bg-white/5 border border-white/5 rounded-3xl p-5 hover:bg-white/10 transition-all duration-300 flex flex-col justify-between"
                        >
                          <div>
                            <div className="aspect-square rounded-2xl overflow-hidden mb-4 relative bg-zinc-950 shadow-inner">
                              <img src={p.cover_image} alt={p.title} className="w-full h-full object-cover" />
                              <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                                <button
                                  onClick={() => setSelectedPlaylist(p)}
                                  className="px-5 py-2.5 bg-white text-black text-xs font-bold rounded-full hover:scale-105 transition-transform"
                                >
                                  Assemble Tracklist
                                </button>
                              </div>
                            </div>
                            <h3 className="text-sm font-bold text-white mb-1.5 truncate">{p.title}</h3>
                            <p className="text-xs text-gray-400 line-clamp-2">{p.description}</p>
                          </div>

                          <div className="mt-4 flex items-center justify-between border-t border-white/5 pt-4 text-xs">
                            <span className="text-purple-400 font-semibold">{p.tracks.length} Songs</span>
                            <span className="text-gray-500 truncate">By {p.ownerName}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div>
                    {/* SPECIFIC PLAYLIST DETAIL */}
                    <div className="mb-6 flex gap-3 text-xs">
                      <button onClick={() => setSelectedPlaylist(null)} className="text-purple-400 hover:text-purple-300 font-semibold">← Return to Hub</button>
                    </div>

                    <div className="flex flex-col md:flex-row gap-8 mb-10 items-end">
                      <img src={selectedPlaylist.cover_image} alt={selectedPlaylist.title} className="w-48 h-48 rounded-3xl object-cover shadow-2xl border border-white/10" />
                      <div className="flex-1">
                        <span className="text-[10px] text-purple-400 font-black tracking-widest uppercase bg-purple-950/40 border border-purple-500/20 px-2.5 py-1 rounded-full inline-block mb-2">Interactive Sound Playlist</span>
                        <h2 className="text-3xl font-black mb-1.5">{selectedPlaylist.title}</h2>
                        <p className="text-xs text-gray-400 mb-4">{selectedPlaylist.description}</p>
                        
                        <div className="flex items-center gap-6 mt-4 text-xs font-semibold text-gray-300">
                          <span>Owner: <strong className="text-white">{selectedPlaylist.ownerName}</strong></span>
                          <span>Collaborators: <strong className="text-purple-300">{selectedPlaylist.collaborators.length} Joined</strong></span>
                          {currentUser?.id === selectedPlaylist.ownerId && (
                            <button onClick={() => handleDeletePlaylist(selectedPlaylist.id)} className="text-rose-400 hover:underline hover:text-rose-300 flex items-center gap-1">
                              <Trash2 className="w-3.5 h-3.5" /> Close Station
                            </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Invite Collaborator Section */}
                    {currentUser?.id === selectedPlaylist.ownerId && (
                      <div className="p-4 bg-white/5 border border-white/5 rounded-2xl mb-8 flex items-center gap-4">
                        <span className="text-xs font-semibold text-gray-300 shrink-0">Add Editor Username:</span>
                        <input
                          type="text"
                          value={inviteUserId}
                          onChange={(e) => setInviteUserId(e.target.value)}
                          placeholder="Username (e.g. ZenDev)"
                          className="bg-white/5 border border-white/10 text-xs px-3 py-1.5 rounded-lg focus:outline-none"
                        />
                        <button
                          onClick={() => handleInviteToCollaborate(selectedPlaylist.id)}
                          className="px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-xs font-bold rounded-lg"
                        >
                          Invite Collaborator
                        </button>
                      </div>
                    )}

                    {/* Playlist Track listing */}
                    <div>
                      <h3 className="text-xs font-black tracking-widest text-purple-400 uppercase mb-4">Tracklist Selection</h3>
                      
                      <div className="divide-y divide-white/5 bg-white/5 rounded-2xl overflow-hidden border border-white/5">
                        {tracks.filter(t => selectedPlaylist.tracks.includes(t.id)).length === 0 ? (
                          <div className="py-8 text-center text-xs text-gray-500">No tracks attached to this station package. Add some below!</div>
                        ) : (
                          tracks.filter(t => selectedPlaylist.tracks.includes(t.id)).map((track, idx) => (
                            <div key={`plat-track-${track.id}`} className="px-6 py-3 flex items-center justify-between hover:bg-white/5 group transition-colors">
                              <div className="flex items-center gap-3 overflow-hidden">
                                <span className="text-xs font-bold text-gray-600">{idx + 1}</span>
                                <img src={track.cover_image} alt={track.title} className="w-8 h-8 rounded-md object-cover" />
                                <div className="overflow-hidden">
                                  <p className="text-xs font-bold text-white truncate">{track.title}</p>
                                  <span className="text-[10px] text-gray-400 truncate">{track.artist}</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-4">
                                <button
                                  onClick={() => handlePlayTrack(track, tracks.filter(t => selectedPlaylist.tracks.includes(t.id)))}
                                  className="p-1.5 bg-white text-black rounded-full hover:scale-105"
                                >
                                  <Play className="w-3 h-3 fill-current ml-0.5" />
                                </button>
                                <button
                                  onClick={() => handleRemoveTrackFromPlaylist(selectedPlaylist.id, track.id)}
                                  className="p-1 text-gray-500 hover:text-rose-400"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>

                      {/* Add available catalog songs to Playlist */}
                      <div className="mt-10">
                        <h4 className="text-xs uppercase font-black tracking-widest text-gray-400 mb-4">Add Tracks to this Station Package</h4>
                        <div className="grid md:grid-cols-2 gap-4">
                          {tracks.filter(t => !selectedPlaylist.tracks.includes(t.id)).slice(0, 6).map(track => (
                            <div key={`add-${track.id}`} className="p-3 bg-white/5 border border-white/5 hover:border-white/10 rounded-2xl flex items-center justify-between">
                              <div className="flex items-center gap-3 overflow-hidden">
                                <img src={track.cover_image} alt={track.title} className="w-10 h-10 rounded-xl object-cover" />
                                <div className="overflow-hidden">
                                  <p className="text-xs font-bold text-white truncate">{track.title}</p>
                                  <p className="text-[10px] text-gray-400 truncate">{track.artist}</p>
                                </div>
                              </div>
                              <button
                                onClick={() => handleAddTrackToPlaylist(selectedPlaylist.id, track.id)}
                                className="px-3 py-1.5 bg-white/10 hover:bg-white text-white hover:text-black text-[10px] font-black rounded-lg transition-colors"
                              >
                                + Add Track
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>
                  </div>
                )}
              </div>
            )}


            {/* PREMIUM MUSIC VIP PLANS */}
            {activeTab === 'premium' && (
              <div>
                <div className="mb-8 text-center max-w-2xl mx-auto">
                  <span className="px-3 py-1 bg-gradient-to-r from-purple-500 to-blue-500 text-[9px] font-black tracking-widest uppercase rounded-full">Audiophile Node</span>
                  <h2 className="text-3xl font-black mt-3 mb-2">SonicX VIP Subscriptions</h2>
                  <p className="text-xs text-gray-400 leading-normal">
                    Fling the limits aside. Play offline using custom verified DRM lockers. 0 ads on lossless network connections.
                  </p>
                </div>

                {/* Promotional Coupon Entry */}
                <div className="mb-10 max-w-md mx-auto bg-white/5 border border-white/5 p-5 rounded-3xl flex items-center gap-3">
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder="ENTER COUPON (e.g., MUSICVIP, FREEPASS)"
                    className="bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-xs placeholder-gray-500 focus:outline-none w-full text-center tracking-widest font-bold uppercase focus:border-purple-500"
                  />
                  <button
                    onClick={applyCoupon}
                    className="px-5 py-2.5 bg-white text-black text-xs font-black rounded-xl hover:bg-purple-100 shrink-0"
                  >
                    Apply Coupon
                  </button>
                </div>

                {couponAppliedCode && (
                  <div className="max-w-md mx-auto mb-6 p-3.5 bg-purple-900/30 border border-purple-500/30 text-xs font-bold rounded-xl text-center text-purple-300">
                    Active Coupon: {couponAppliedCode} (-{couponDiscount}% discount!)
                  </div>
                )}

                {/* Simulated Payment Gateway State feedback */}
                {billingStatus && (
                  <div className="max-w-md mx-auto mb-8 p-6 bg-[#0c0525] border border-purple-500/40 rounded-3xl text-center">
                    {billingStatus === 'processing' && (
                      <div className="space-y-3">
                        <div className="w-8 h-8 rounded-full border-t-2 border-purple-500 border-r-2 animate-spin mx-auto"></div>
                        <p className="text-xs font-bold text-purple-300">Contacting Stripe & Razorpay secured endpoints...</p>
                      </div>
                    )}
                    {billingStatus === 'success' && (
                      <div className="space-y-2">
                        <CheckCircle2 className="w-10 h-10 text-green-400 mx-auto" />
                        <p className="text-xs font-bold text-green-400">Payment Processed Successfully! Premium node synced.</p>
                      </div>
                    )}
                    {billingStatus === 'failed' && (
                      <p className="text-xs font-bold text-rose-400">Payment failed or rejected by simulated bank gateway.</p>
                    )}
                  </div>
                )}

                {/* PLANS CHIPS */}
                <div className="grid md:grid-cols-2 max-w-4xl mx-auto gap-8">
                  {/* FREE TIER */}
                  <div className="bg-white/5 border border-white/5 rounded-[32px] p-8 flex flex-col justify-between">
                    <div>
                      <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Base Plan</span>
                      <h3 className="text-2xl font-black mt-2 mb-1">Standard Node</h3>
                      <p className="text-3xl font-black text-white">$0.00 <span className="text-xs font-normal text-gray-500">/ forever</span></p>
                      
                      <div className="divide-y divide-white/5 mt-8 space-y-4 text-xs text-gray-300">
                        <div className="flex items-center gap-2.5 pt-3">
                          <Check className="w-4 h-4 text-purple-400 shrink-0" />
                          <span>Standard 128kbps quality stream</span>
                        </div>
                        <div className="flex items-center gap-2.5 pt-3">
                          <Check className="w-4 h-4 text-purple-400 shrink-0" />
                          <span>Simulated ad slots</span>
                        </div>
                        <div className="flex items-center gap-2.5 pt-3">
                          <Check className="w-4 h-4 text-purple-400 shrink-0" />
                          <span>Dynamic playlists & search API</span>
                        </div>
                      </div>
                    </div>

                    <button className="w-full mt-10 py-3 bg-white/10 text-gray-300 text-xs font-bold rounded-xl pointer-events-none">
                      Active Free Slot
                    </button>
                  </div>

                  {/* PREMIUM TIER */}
                  <div className="bg-gradient-to-br from-purple-950/40 via-blue-950/40 to-[#030014] border-2 border-purple-500/40 rounded-[32px] p-8 relative flex flex-col justify-between shadow-2xl">
                    <div className="absolute top-4 right-4 text-xs font-extrabold tracking-widest bg-purple-500 text-white px-3 py-1 rounded-full uppercase">Most chosen</div>
                    <div>
                      <span className="text-xs font-bold text-purple-400 uppercase tracking-widest">Full Audio VIP</span>
                      <h3 className="text-3xl font-black mt-2 mb-1">SONICX PREMIUM</h3>
                      <p className="text-3xl font-black text-white">
                        {couponDiscount > 0
                          ? `$${(9.99 * (1 - couponDiscount / 100)).toFixed(2)}`
                          : "$9.99"
                        }
                        <span className="text-xs font-normal text-gray-500"> / month</span>
                      </p>

                      <div className="divide-y divide-white/5 mt-8 space-y-4 text-xs text-gray-300">
                        <div className="flex items-center gap-2.5 pt-3">
                          <Check className="w-4 h-4 text-purple-400 shrink-0" />
                          <span>Lossless Hi-Res (24-bit FLAC quality)</span>
                        </div>
                        <div className="flex items-center gap-2.5 pt-3">
                          <Check className="w-4 h-4 text-purple-400 shrink-0" />
                          <span>Simulated <strong>Offline DRM Track Downloads</strong></span>
                        </div>
                        <div className="flex items-center gap-2.5 pt-3">
                          <Check className="w-4 h-4 text-purple-400 shrink-0" />
                          <span>Active Gemini Server recommendation support</span>
                        </div>
                        <div className="flex items-center gap-2.5 pt-3">
                          <Check className="w-4 h-4 text-purple-400 shrink-0" />
                          <span>Zero ad intermissions</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-10 space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <button
                          onClick={() => handleSubscribe('PREMIUM', 'Stripe')}
                          className="py-3 bg-purple-600 hover:bg-purple-700 text-white text-xs font-black rounded-xl transition-colors shrink-0"
                        >
                          Checkout via Stripe
                        </button>
                        <button
                          onClick={() => handleSubscribe('PREMIUM', 'Razorpay')}
                          className="py-3 bg-transparent border border-purple-500/40 hover:bg-purple-900/10 text-white text-xs font-black rounded-xl transition-colors shrink-0"
                        >
                          Razorpay Pay
                        </button>
                      </div>
                      
                      <button
                        onClick={handleActiveTrial}
                        className="w-full py-2 bg-white text-black hover:bg-purple-100 text-xs font-extrabold rounded-xl transition-colors"
                      >
                        Try 7 Days Free Trial
                      </button>

                      {currentUser?.subscription_type === 'PREMIUM' && (
                        <button onClick={handleCancelSubscription} className="w-full text-center text-[10px] text-gray-500 hover:text-rose-400 hover:underline">
                          Cancel active subscription plan
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}


            {/* DYNAMIC BACKEND DATABASE CATALOG ADMIN */}
            {activeTab === 'admin' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h2 className="text-2xl font-black tracking-tight text-white mb-1">Catalog Controller Node</h2>
                    <p className="text-xs text-gray-400">Directly add tracks to local database, view live user stream plays statistics.</p>
                  </div>
                  <button
                    onClick={fetchAdminAnalytics}
                    className="px-4 py-2 bg-white/5 border border-white/5 rounded-xl text-xs hover:bg-white/10"
                  >
                    Refresh Intel
                  </button>
                </div>

                {/* Analytical counters in grid layout */}
                {adminAnalytics && (
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
                    <div className="bg-white/5 p-5 rounded-2xl border border-white/5">
                      <p className="text-xs text-purple-400 font-bold uppercase tracking-widest">Total Stream Plays</p>
                      <p className="text-2xl font-black text-white mt-1.5">{adminAnalytics.totalPlays?.toLocaleString()}</p>
                    </div>
                    <div className="bg-white/5 p-5 rounded-2xl border border-white/5">
                      <p className="text-xs text-purple-400 font-bold uppercase tracking-widest">Subscribed Users</p>
                      <p className="text-2xl font-black text-white mt-1.5">{adminAnalytics.totalUsers}</p>
                    </div>
                    <div className="bg-white/5 p-5 rounded-2xl border border-white/5">
                      <p className="text-xs text-purple-400 font-bold uppercase tracking-widest">Audio Tracks</p>
                      <p className="text-2xl font-black text-white mt-1.5">{adminAnalytics.totalSongs}</p>
                    </div>
                    <div className="bg-white/5 p-5 rounded-2xl border border-white/5">
                      <p className="text-xs text-purple-400 font-bold uppercase tracking-widest">Simulated Revenue</p>
                      <p className="text-2xl font-black text-green-400 mt-1.5">${adminAnalytics.revenue} / month</p>
                    </div>
                  </div>
                )}

                {/* Add Custom Sound Track Layout */}
                <div className="p-6 bg-[#09051d] border border-white/10 rounded-3xl mb-10">
                  <h3 className="text-sm font-black text-purple-300 uppercase mb-4">Upload New Sound Stream</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase text-gray-400">Track Title</label>
                      <input
                        type="text"
                        value={adminNewSong.title}
                        onChange={(e) => setAdminNewSong({ ...adminNewSong, title: e.target.value })}
                        placeholder="e.g. Hyper Drift 2088"
                        className="w-full bg-white/5 border border-white/10 px-3 py-2 text-xs rounded-xl focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase text-gray-400">Creator Artist</label>
                      <input
                        type="text"
                        value={adminNewSong.artist}
                        onChange={(e) => setAdminNewSong({ ...adminNewSong, artist: e.target.value })}
                        placeholder="e.g. Vector Vandal"
                        className="w-full bg-white/5 border border-white/10 px-3 py-2 text-xs rounded-xl focus:outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase text-gray-400">Genre</label>
                      <select
                        value={adminNewSong.genre}
                        onChange={(e) => setAdminNewSong({ ...adminNewSong, genre: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 px-3 py-2 text-xs rounded-xl focus:outline-none text-white block cursor-pointer"
                      >
                        <option value="Synthwave">Synthwave</option>
                        <option value="Ambient">Ambient</option>
                        <option value="Lofi Hip Hop">Lofi Hip Hop</option>
                        <option value="Cyberpunk">Cyberpunk</option>
                        <option value="Techno">Techno</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4 mt-4">
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase text-gray-400">Sound File URL (MP3 Address)</label>
                      <input
                        type="text"
                        value={adminNewSong.audio_file}
                        onChange={(e) => setAdminNewSong({ ...adminNewSong, audio_file: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 px-3 py-2 text-xs rounded-xl focus:outline-none text-purple-300"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase text-gray-400">Cover Graphic URL</label>
                      <input
                        type="text"
                        value={adminNewSong.cover_image}
                        onChange={(e) => setAdminNewSong({ ...adminNewSong, cover_image: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 px-3 py-2 text-xs rounded-xl focus:outline-none text-purple-300"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] uppercase text-gray-400">Duration (seconds)</label>
                      <input
                        type="number"
                        value={adminNewSong.duration}
                        onChange={(e) => setAdminNewSong({ ...adminNewSong, duration: parseInt(e.target.value) || 240 })}
                        className="w-full bg-white/5 border border-white/10 px-3 py-2 text-xs rounded-xl focus:outline-none"
                      />
                    </div>
                  </div>

                  <button
                    onClick={handleAdminCreateSong}
                    className="mt-6 px-6 py-2.5 bg-gradient-to-r from-purple-600 to-blue-600 font-extrabold text-xs rounded-xl hover:scale-102 transition-transform"
                  >
                    Commit Track to Database
                  </button>
                </div>

                {/* DB Track table rows list */}
                <h3 className="text-xs uppercase font-black tracking-widest text-purple-400 mb-4 text-left">Active Sound Files Registered</h3>
                <div className="divide-y divide-white/5 bg-white/5 border border-white/5 rounded-2xl overflow-hidden shadow-xl">
                  {tracks.map(t => (
                    <div key={`admin-${t.id}`} className="px-6 py-3.5 flex justify-between items-center text-xs">
                      <div className="flex items-center gap-3">
                        <img src={t.cover_image} alt={t.title} className="w-8 h-8 rounded-lg object-cover" />
                        <div>
                          <p className="font-extrabold text-white">{t.title}</p>
                          <p className="text-[10px] text-purple-400 mt-0.5">{t.artist} • {t.genre}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6">
                        <span className="text-gray-400">{t.plays.toLocaleString()} Plays</span>
                        <button
                          onClick={async () => {
                            await fetch(`/api/tracks/${t.id}`, { method: 'DELETE' });
                            fetchTracks();
                            fetchAdminAnalytics();
                          }}
                          className="p-1 px-3 bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white rounded-lg transition-colors text-[10px]"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

              </div>
            )}


            {/* SOCIAL FEED & RECENT ACTIVITY CHATS */}
            {activeTab === 'social' && (
              <div>
                <div className="mb-6">
                  <h2 className="text-2xl font-black tracking-tight mb-1">Live Social activity feeds</h2>
                  <p className="text-xs text-gray-400">Interact with online comments, follow verified channels, or share your active playlists.</p>
                </div>

                <div className="grid lg:grid-cols-3 gap-8">
                  {/* Share Station Card */}
                  <div className="bg-white/5 border border-white/5 p-6 rounded-3xl h-fit">
                    <h3 className="text-sm font-bold tracking-tight mb-4 flex items-center gap-1 text-purple-400"><Share2 className="w-4 h-4" /> Share with Crew</h3>
                    <p className="text-xs text-gray-400 mb-6">Instantly spread the transmission link out securely using standard social vectors.</p>
                    
                    <div className="space-y-2.5">
                      <a href={`https://wa.me/?text=${encodeURIComponent('Listening to epic cyber synth lounge on Online Music Gallery! Check it: ' + window.location.href)}`} target="_blank" className="w-full py-2.5 px-4 bg-green-600/20 hover:bg-green-600 text-white hover:text-black font-extrabold text-xs rounded-xl flex items-center justify-between transition-colors">
                        <span>Share on WhatsApp</span>
                        <ChevronRight className="w-4 h-4" />
                      </a>
                      <a href={`https://twitter.com/intent/tweet?text=${encodeURIComponent('Syncing cosmic audio vibes on Online Music Gallery ' + window.location.href)}`} target="_blank" className="w-full py-2.5 px-4 bg-blue-400/20 hover:bg-blue-400 text-white hover:text-black font-extrabold text-xs rounded-xl flex items-center justify-between transition-colors">
                        <span>Post to Twitter</span>
                        <ChevronRight className="w-4 h-4" />
                      </a>
                    </div>
                  </div>

                  {/* Comments Box Panel */}
                  <div className="col-span-2 bg-[#09051d] border border-white/10 rounded-3xl p-6">
                    <h3 className="text-xs font-black tracking-widest text-purple-400 uppercase mb-4">Transmission Broadcast Chats</h3>
                    
                    {currentTrack ? (
                      <div>
                        {/* Send comments form */}
                        <form onSubmit={(e) => handleAddComment(e, currentTrack.id)} className="flex items-center gap-3 mb-6 bg-white/5 rounded-2xl border border-white/5 px-4 py-2.5">
                          <input
                            type="text"
                            value={newCommentText}
                            onChange={(e) => setNewCommentText(e.target.value)}
                            placeholder={`Comment on '${currentTrack.title}'...`}
                            className="bg-transparent border-none text-xs text-white focus:outline-none w-full"
                          />
                          <button type="submit" className="p-2 bg-purple-600 text-white rounded-xl hover:scale-105 transition-colors">
                            <Send className="w-4 h-4" />
                          </button>
                        </form>

                        <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
                          {trackComments.length === 0 ? (
                            <p className="text-xs text-gray-500 text-center py-6">Be the first to comment on this transmission wave!</p>
                          ) : (
                            trackComments.map(c => (
                              <div key={c.id} className="p-4 bg-white/5 border border-white/5 rounded-2xl flex gap-3.5">
                                <img
                                  src={c.userAvatar || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${c.username}`}
                                  className="w-8 h-8 rounded-xl object-cover"
                                  alt="avatar"
                                />
                                <div>
                                  <div className="flex items-center gap-2 mb-1">
                                    <span className="text-xs font-bold text-white">{c.username}</span>
                                    <span className="text-[9px] text-gray-500">{new Date(c.created_at).toLocaleDateString()}</span>
                                  </div>
                                  <p className="text-xs text-gray-300 leading-normal">{c.comment}</p>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-gray-500 text-center py-10">Select an active playing track from bottom deck or grid first to view or insert comments!</p>
                    )}
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* BOTTOM FLOATING PLAYER MUSIC DECK */}
          <div className="h-28 bg-[#09051d]/90 backdrop-blur-3xl border-t border-white/5 px-8 flex items-center justify-between z-40 shrink-0">
            {/* Playing track summary */}
            <div className="flex items-center gap-4 w-72">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-blue-500 rounded-xl overflow-hidden shadow-lg border border-white/10 shrink-0 relative flex items-center justify-center">
                {currentTrack ? (
                  <img src={currentTrack.cover_image} alt={currentTrack.title} className="w-full h-full object-cover" />
                ) : (
                  <Music className="w-6 h-6 text-purple-400" />
                )}
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-bold truncate text-white">
                  {currentTrack ? currentTrack.title : 'Ready to stream'}
                </p>
                <p className="text-[10px] text-purple-400 truncate mt-0.5">
                  {currentTrack ? `${currentTrack.artist} • ${currentTrack.genre}` : 'Select a tune'}
                </p>
              </div>
              {currentTrack && (
                <button
                  onClick={() => handleToggleLike(currentTrack.id)}
                  className={`text-gray-500 hover:text-rose-500 ml-2 transition-colors ${likedTrackIds.includes(currentTrack.id) ? 'text-rose-500' : ''}`}
                >
                  <Heart className={`w-4 h-4 ${likedTrackIds.includes(currentTrack.id) ? 'fill-current' : ''}`} />
                </button>
              )}
            </div>

            {/* Main Player deck sliders and buttons */}
            <div className="flex flex-col items-center gap-2 flex-1 max-w-lg">
              
              <div className="flex items-center gap-6">
                <button
                  onClick={() => setIsShuffle(!isShuffle)}
                  className={`text-xs font-semibold ${isShuffle ? 'text-purple-400' : 'text-gray-500 hover:text-white'}`}
                  title="Shuffle toggle"
                >
                  Shuffle: {isShuffle ? 'ON' : 'OFF'}
                </button>
                
                <button onClick={handlePrevTrack} className="text-gray-300 hover:text-white transition-transform hover:scale-105" title="Previous Song">
                  <SkipBack className="w-5 h-5 fill-current" />
                </button>
                
                <button
                  onClick={handleTogglePlay}
                  className="w-12 h-12 bg-white text-black hover:scale-110 rounded-full flex items-center justify-center transition-all shadow-md shadow-purple-500/10"
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5 fill-current text-black" />
                  ) : (
                    <Play className="w-5 h-5 fill-current text-black ml-0.5" />
                  )}
                </button>
                
                <button onClick={handleNextTrack} className="text-gray-300 hover:text-white transition-transform hover:scale-105" title="Next Song">
                  <SkipForward className="w-5 h-5 fill-current" />
                </button>

                <button
                  onClick={() => setIsRepeat(!isRepeat)}
                  className={`text-xs font-semibold ${isRepeat ? 'text-purple-400' : 'text-gray-500 hover:text-white'}`}
                  title="Repeat toggle"
                >
                  Repeat: {isRepeat ? 'ON' : 'OFF'}
                </button>
              </div>

              {/* Progress Slider */}
              <div className="w-full flex items-center gap-3 text-[10px] font-medium text-gray-500">
                <span className="w-8 text-right">{formatTime(currentTime)}</span>
                <div
                  onClick={handleProgressBarClick}
                  className="flex-1 h-1.5 bg-white/10 rounded-full cursor-pointer relative"
                >
                  <div
                    style={{ width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%` }}
                    className="absolute inset-y-0 left-0 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full"
                  />
                </div>
                <span className="w-8 text-left">{formatTime(duration)}</span>
              </div>
            </div>

            {/* Equalizer Visualizer display bar */}
            <div className="flex items-center gap-4 w-72 justify-end">
              
              {/* Audio Equalizer visualizer */}
              <div className="relative border border-white/5 rounded-xl bg-white/5 overflow-hidden w-28 h-12 mr-3 px-1 hidden md:block">
                <canvas ref={canvasRef} width="112" height="48" className="block w-full h-full" />
              </div>

              {/* Volume sliders */}
              <div className="flex items-center gap-2">
                <button onClick={() => setIsMuted(!isMuted)} className="text-gray-400 hover:text-white">
                  {isMuted ? <VolumeX className="w-4 h-4 text-rose-500" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={volume}
                  onChange={(e) => setVolume(parseInt(e.target.value))}
                  className="w-20 accent-purple-500 cursor-pointer h-1"
                />
              </div>

            </div>
          </div>

        </main>
      </div>

      {/* SECURE REGISTER & LOGIN FULL-SCREEN DIALOG MODAL SKELETON */}
      {authView && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xl flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-md bg-[#09051d] border border-purple-500/20 rounded-[32px] p-8 shadow-2xl relative">
            <button
              onClick={() => { setAuthView(null); setAuthError(null); setAuthSuccessMsg(null); }}
              className="absolute top-6 right-6 text-gray-500 hover:text-white font-extrabold text-sm"
            >
              Close ✕
            </button>

            <div className="text-center mb-6">
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white to-purple-400">
                {authView === 'login' ? 'Sync Profile Node' : authView === 'register' ? 'Deploy SonicX Credentials' : 'Retrieve Intelligence'}
              </h3>
              <p className="text-xs text-gray-400 mt-1">Unlock high-quality playlist integrations & smart database comments.</p>
            </div>

            {authError && <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs rounded-xl text-center mb-4">{authError}</div>}
            {authSuccessMsg && <div className="p-3 bg-green-500/10 border border-green-500/20 text-green-400 text-xs rounded-xl text-center mb-4">{authSuccessMsg}</div>}

            {authView !== 'forgot' ? (
              <form onSubmit={handleAuth} className="space-y-4">
                {authView === 'register' && (
                  <div>
                    <input
                      type="text"
                      required
                      value={authUsername}
                      onChange={(e) => setAuthUsername(e.target.value)}
                      placeholder="Transmission Username (e.g. NeonNostalgia)"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 placeholder-gray-500 text-xs text-white focus:outline-none focus:border-purple-500"
                    />
                  </div>
                )}
                <div>
                  <input
                    type="email"
                    required
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    placeholder="Broadcast Email"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 placeholder-gray-500 text-xs text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <input
                    type="password"
                    required
                    value={authPassword}
                    onChange={(e) => setAuthPassword(e.target.value)}
                    placeholder="Secure Lock Passkey"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 placeholder-gray-500 text-xs text-white focus:outline-none focus:border-purple-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-purple-600 to-blue-600 text-xs font-bold rounded-xl text-white hover:scale-102 transition-transform"
                >
                  {authView === 'login' ? 'Verify and Authenticate' : 'Establish Network Slot'}
                </button>
              </form>
            ) : (
              <form onSubmit={handleForgotPassword} className="space-y-4">
                <div>
                  <input
                    type="email"
                    required
                    value={authEmail}
                    onChange={(e) => setAuthEmail(e.target.value)}
                    placeholder="Broadcast Email"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 placeholder-gray-500 text-xs text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-3 bg-purple-600 text-xs font-bold rounded-xl text-white"
                >
                  Generate reset password
                </button>
              </form>
            )}

            {/* Third party SSO buttons */}
            <div className="mt-6 pt-6 border-t border-white/5 space-y-3">
              <span className="text-[10px] text-gray-500 uppercase tracking-widest block text-center">Fast Login SSO</span>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => handleOAuthSimulate('Google')}
                  className="py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[11px] font-bold text-gray-300 hover:text-white transition-colors flex items-center justify-center gap-1.5"
                >
                  Google Node
                </button>
                <button
                  onClick={() => handleOAuthSimulate('Facebook')}
                  className="py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[11px] font-bold text-gray-300 hover:text-white transition-colors flex items-center justify-center gap-1.5"
                >
                  Facebook Identity
                </button>
              </div>
            </div>

            <div className="mt-4 flex justify-between text-[11px] text-gray-500 px-1">
              {authView === 'login' ? (
                <>
                  <button onClick={() => { setAuthView('register'); setAuthError(null); }} className="hover:text-purple-400">Register new profile</button>
                  <button onClick={() => { setAuthView('forgot'); setAuthError(null); }} className="hover:text-purple-400">Forgot Passkey?</button>
                </>
              ) : (
                <button onClick={() => { setAuthView('login'); setAuthError(null); }} className="hover:text-purple-400 mx-auto">Already registered? Sign In</button>
              )}
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
