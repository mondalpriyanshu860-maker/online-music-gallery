import fs from 'fs';
import path from 'path';
import { User, Artist, Album, Track, Playlist, Comment, ListeningHistory, Notification } from '../types';

const DB_FILE = path.join(process.cwd(), 'database.json');

interface DatabaseSchema {
  users: Record<string, User & { passwordHash: string }>;
  artists: Record<string, Artist>;
  albums: Record<string, Album>;
  tracks: Record<string, Track>;
  playlists: Record<string, Playlist>;
  comments: Comment[];
  likes: { userId: string; trackId: string }[];
  history: ListeningHistory[];
  notifications: Record<string, Notification[]>;
  coupons: Record<string, number>; // couponName -> discountPercentage
}

// Initial seed data
const INITIAL_ARTISTS: Record<string, Artist> = {
  'art-1': {
    id: 'art-1',
    name: 'Vector Vandal',
    image: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&q=80&w=200',
    biography: 'Slaying grid lines and synthesis in the heart of Neon Tokyo since 2088.',
    followers: 124500,
    isVerified: true,
  },
  'art-2': {
    id: 'art-2',
    name: 'Cosmic Slumber',
    image: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?auto=format&fit=crop&q=80&w=200',
    biography: 'Eno-inspired ambient architecture using vintage reel-to-reel and granular samplers.',
    followers: 84300,
    isVerified: true,
  },
  'art-3': {
    id: 'art-3',
    name: 'Glitch Horizon',
    image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80&w=200',
    biography: 'A collaborative group merging physical hardware circuit bending with mathematical jazz.',
    followers: 53200,
    isVerified: false,
  },
  'art-4': {
    id: 'art-4',
    name: 'Luna Lounge',
    image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&q=80&w=200',
    biography: 'Late night lofi grooves crafted under the glow of the lunar phase.',
    followers: 210000,
    isVerified: true,
  }
};

const INITIAL_ALBUMS: Record<string, Album> = {
  'alb-1': {
    id: 'alb-1',
    title: 'Grid Runner',
    cover_image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=400',
    artistId: 'art-1',
    artistName: 'Vector Vandal',
    release_date: '2026-01-01'
  },
  'alb-2': {
    id: 'alb-2',
    title: 'Gravity Well',
    cover_image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&q=80&w=400',
    artistId: 'art-2',
    artistName: 'Cosmic Slumber',
    release_date: '2025-06-12'
  },
  'alb-3': {
    id: 'alb-3',
    title: 'Binary Eclipse',
    cover_image: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&q=80&w=400',
    artistId: 'art-3',
    artistName: 'Glitch Horizon',
    release_date: '2026-03-24'
  },
  'alb-4': {
    id: 'alb-4',
    title: 'Midnight Tea',
    cover_image: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&q=80&w=400',
    artistId: 'art-4',
    artistName: 'Luna Lounge',
    release_date: '2026-05-18'
  }
};

const INITIAL_TRACKS: Record<string, Track> = {
  'track-1': {
    id: 'track-1',
    title: 'Synthwave Genesis',
    artist: 'Vector Vandal',
    artistId: 'art-1',
    album: 'Grid Runner',
    albumId: 'alb-1',
    genre: 'Synthwave',
    audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    cover_image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=400',
    duration: 372,
    plays: 52403,
    likes: 4210,
    upload_date: '2026-01-01'
  },
  'track-2': {
    id: 'track-2',
    title: 'Neon Drift',
    artist: 'Vector Vandal',
    artistId: 'art-1',
    album: 'Grid Runner',
    albumId: 'alb-1',
    genre: 'Synthwave',
    audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    cover_image: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?auto=format&fit=crop&q=80&w=400',
    duration: 423,
    plays: 38240,
    likes: 3102,
    upload_date: '2026-01-15'
  },
  'track-3': {
    id: 'track-3',
    title: 'Event Horizon',
    artist: 'Cosmic Slumber',
    artistId: 'art-2',
    album: 'Gravity Well',
    albumId: 'alb-2',
    genre: 'Ambient',
    audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    cover_image: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?auto=format&fit=crop&q=80&w=400',
    duration: 344,
    plays: 124502,
    likes: 11090,
    upload_date: '2025-06-12'
  },
  'track-4': {
    id: 'track-4',
    title: 'Solar Flare',
    artist: 'Cosmic Slumber',
    artistId: 'art-2',
    album: 'Gravity Well',
    albumId: 'alb-2',
    genre: 'Ambient',
    audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    cover_image: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&q=80&w=400',
    duration: 302,
    plays: 91402,
    likes: 7421,
    upload_date: '2025-07-01'
  },
  'track-5': {
    id: 'track-5',
    title: 'Digital Rain',
    artist: 'Glitch Horizon',
    artistId: 'art-3',
    album: 'Binary Eclipse',
    albumId: 'alb-3',
    genre: 'Cyberpunk',
    audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3',
    cover_image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80&w=400',
    duration: 362,
    plays: 18230,
    likes: 1204,
    upload_date: '2026-03-24'
  },
  'track-6': {
    id: 'track-6',
    title: 'Subroutine 0xFF',
    artist: 'Glitch Horizon',
    artistId: 'art-3',
    album: 'Binary Eclipse',
    albumId: 'alb-3',
    genre: 'Cyberpunk',
    audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3',
    cover_image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&q=80&w=400',
    duration: 532,
    plays: 14210,
    likes: 980,
    upload_date: '2026-04-02'
  },
  'track-7': {
    id: 'track-7',
    title: 'Chamber Chai',
    artist: 'Luna Lounge',
    artistId: 'art-4',
    album: 'Midnight Tea',
    albumId: 'alb-4',
    genre: 'Lofi Hip Hop',
    audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3',
    cover_image: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&q=80&w=400',
    duration: 412,
    plays: 284300,
    likes: 24500,
    upload_date: '2026-05-18'
  },
  'track-8': {
    id: 'track-8',
    title: 'Sleepy Raindrops',
    artist: 'Luna Lounge',
    artistId: 'art-4',
    album: 'Midnight Tea',
    albumId: 'alb-4',
    genre: 'Lofi Hip Hop',
    audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    cover_image: 'https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?auto=format&fit=crop&q=80&w=400',
    duration: 318,
    plays: 341200,
    likes: 38902,
    upload_date: '2026-05-25'
  },
  'track-9': {
    id: 'track-9',
    title: 'Techno Grid Runner',
    artist: 'Vector Vandal',
    artistId: 'art-1',
    album: 'Grid Runner',
    albumId: 'alb-1',
    genre: 'Techno',
    audio_file: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3',
    cover_image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=400',
    duration: 458,
    plays: 43900,
    likes: 3824,
    upload_date: '2026-06-01'
  }
};

const INITIAL_PLAYLISTS: Record<string, Playlist> = {
  'plat-1': {
    id: 'plat-1',
    title: 'Late Night Coding',
    description: 'High performance loops and ambient grids for maximum focus.',
    cover_image: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?auto=format&fit=crop&q=80&w=300',
    ownerId: 'system',
    ownerName: 'Editor\'s Choice',
    tracks: ['track-1', 'track-3', 'track-5', 'track-7', 'track-9'],
    collaborators: [],
    followers: 8431,
    isPublic: true
  },
  'plat-2': {
    id: 'plat-2',
    title: 'Sunset Dreams',
    description: 'Soothing synths and slow tempo lofi under the fading skies.',
    cover_image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=300',
    ownerId: 'system',
    ownerName: 'Chill Station',
    tracks: ['track-2', 'track-4', 'track-6', 'track-8'],
    collaborators: [],
    followers: 12044,
    isPublic: true
  }
};

const INITIAL_COUPONS: Record<string, number> = {
  'MUSICVIP': 50, // 50% discount
  'NEON20': 20,   // 20% discount
  'FREEPASS': 100 // 100% discount / Free trial upgrade
};

class LocalDatabase {
  private data: DatabaseSchema;

  constructor() {
    this.data = {
      users: {},
      artists: INITIAL_ARTISTS,
      albums: INITIAL_ALBUMS,
      tracks: INITIAL_TRACKS,
      playlists: INITIAL_PLAYLISTS,
      comments: [
        {
          id: 'comm-1',
          userId: 'system',
          username: 'NeonNostalgia',
          trackId: 'track-1',
          comment: 'This synth intro literally teleports my soul into a custom cyber coupe.',
          created_at: '2026-06-18T12:00:00.000Z'
        },
        {
          id: 'comm-2',
          userId: 'system',
          username: 'ZenDev',
          trackId: 'track-3',
          comment: 'Perfect coding background noise. No sudden spikes, just sleek, clean waves.',
          created_at: '2026-06-19T02:30:00.000Z'
        }
      ],
      likes: [],
      history: [],
      notifications: {},
      coupons: INITIAL_COUPONS
    };
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        // Deep merge or overwrite keys to preserve our static list in development
        this.data = {
          ...this.data,
          ...parsed,
          // Re-instantiate base initial seed tracks / artists if empty
          artists: { ...INITIAL_ARTISTS, ...(parsed.artists || {}) },
          albums: { ...INITIAL_ALBUMS, ...(parsed.albums || {}) },
          tracks: { ...INITIAL_TRACKS, ...(parsed.tracks || {}) },
          playlists: { ...INITIAL_PLAYLISTS, ...(parsed.playlists || {}) },
          coupons: { ...INITIAL_COUPONS, ...(parsed.coupons || {}) }
        };
      } else {
        this.save();
      }
    } catch (err) {
      console.error('Error reading database file:', err);
    }
  }

  private save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error writing database file:', err);
    }
  }

  // --- Users Operations ---
  public getUser(id: string): User | undefined {
    const raw = this.data.users[id];
    if (!raw) return undefined;
    const { passwordHash, ...user } = raw;
    return user as User;
  }

  public getUserByEmail(email: string): (User & { passwordHash: string }) | undefined {
    return Object.values(this.data.users).find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public createUser(user: User, passwordHash: string): User {
    this.data.users[user.id] = { ...user, passwordHash };
    this.save();
    return user;
  }

  public updateUser(id: string, updates: Partial<User>): User | undefined {
    const raw = this.data.users[id];
    if (!raw) return undefined;
    this.data.users[id] = { ...raw, ...updates };
    this.save();
    const { passwordHash, ...user } = this.data.users[id];
    return user as User;
  }

  // --- Artists, Albums, Tracks ---
  public getArtists(): Artist[] {
    return Object.values(this.data.artists);
  }

  public getArtist(id: string): Artist | undefined {
    return this.data.artists[id];
  }

  public updateArtist(id: string, updates: Partial<Artist>): Artist {
    const artist = this.data.artists[id] || { id, name: '', image: '', biography: '', followers: 0 };
    this.data.artists[id] = { ...artist, ...updates };
    this.save();
    return this.data.artists[id];
  }

  public getAlbums(): Album[] {
    return Object.values(this.data.albums);
  }

  public getAlbum(id: string): Album | undefined {
    return this.data.albums[id];
  }

  public updateAlbum(id: string, updates: Partial<Album>): Album {
    const album = this.data.albums[id] || { id, title: '', cover_image: '', artistId: '', artistName: '', release_date: '' };
    this.data.albums[id] = { ...album, ...updates };
    this.save();
    return this.data.albums[id];
  }

  public getTracks(): Track[] {
    return Object.values(this.data.tracks);
  }

  public getTrack(id: string): Track | undefined {
    return this.data.tracks[id];
  }

  public updateTrack(id: string, updates: Partial<Track>): Track {
    const track = this.data.tracks[id] || {
      id,
      title: '',
      artist: '',
      artistId: '',
      album: '',
      albumId: '',
      genre: '',
      audio_file: '',
      cover_image: '',
      duration: 180,
      plays: 0,
      likes: 0,
      upload_date: new Date().toISOString()
    };
    this.data.tracks[id] = { ...track, ...updates };
    this.save();
    return this.data.tracks[id];
  }

  public deleteTrack(id: string) {
    delete this.data.tracks[id];
    this.save();
  }

  // --- Playlists ---
  public getPlaylists(): Playlist[] {
    return Object.values(this.data.playlists);
  }

  public getPlaylist(id: string): Playlist | undefined {
    return this.data.playlists[id];
  }

  public updatePlaylist(id: string, updates: Partial<Playlist>): Playlist {
    const playlist = this.data.playlists[id] || {
      id,
      title: '',
      description: '',
      cover_image: '',
      ownerId: '',
      ownerName: '',
      tracks: [],
      collaborators: [],
      followers: 0,
      isPublic: true
    };
    this.data.playlists[id] = { ...playlist, ...updates };
    this.save();
    return this.data.playlists[id];
  }

  public deletePlaylist(id: string) {
    delete this.data.playlists[id];
    this.save();
  }

  // --- Likes, Comments, History ---
  public getComments(trackId: string): Comment[] {
    return this.data.comments.filter(c => c.trackId === trackId).sort((a,b) => b.created_at.localeCompare(a.created_at));
  }

  public createComment(comment: Comment): Comment {
    this.data.comments.push(comment);
    this.save();
    return comment;
  }

  public getLikes(userId: string): string[] {
    return this.data.likes.filter(l => l.userId === userId).map(l => l.trackId);
  }

  public toggleLike(userId: string, trackId: string): { liked: boolean } {
    const index = this.data.likes.findIndex(l => l.userId === userId && l.trackId === trackId);
    let liked = false;
    if (index === -1) {
      this.data.likes.push({ userId, trackId });
      liked = true;
      if (this.data.tracks[trackId]) {
        this.data.tracks[trackId].likes += 1;
      }
    } else {
      this.data.likes.splice(index, 1);
      liked = false;
      if (this.data.tracks[trackId]) {
        this.data.tracks[trackId].likes = Math.max(0, this.data.tracks[trackId].likes - 1);
      }
    }
    this.save();
    return { liked };
  }

  public addToHistory(userId: string, trackId: string) {
    const hist: ListeningHistory = {
      id: 'hist-' + Math.random().toString(36).substr(2, 9),
      userId,
      trackId,
      listened_at: new Date().toISOString()
    };
    this.data.history.push(hist);

    if (this.data.tracks[trackId]) {
      this.data.tracks[trackId].plays += 1;
    }

    this.save();
  }

  public getHistory(userId: string): ListeningHistory[] {
    return this.data.history.filter(h => h.userId === userId).sort((a,b) => b.listened_at.localeCompare(a.listened_at));
  }

  // --- Notifications ---
  public getNotifications(userId: string): Notification[] {
    return this.data.notifications[userId] || [];
  }

  public addNotification(userId: string, message: string, type: 'social' | 'system' | 'subscription') {
    if (!this.data.notifications[userId]) {
      this.data.notifications[userId] = [];
    }
    const notif: Notification = {
      id: 'notif-' + Math.random().toString(36).substr(2, 9),
      message,
      type,
      created_at: new Date().toISOString(),
      read: false
    };
    this.data.notifications[userId].unshift(notif);
    this.save();
  }

  public markNotificationsRead(userId: string) {
    if (this.data.notifications[userId]) {
      this.data.notifications[userId].forEach(n => n.read = true);
      this.save();
    }
  }

  // --- Coupons ---
  public validateCoupon(code: string): number {
    return this.data.coupons[code.toUpperCase()] || 0;
  }

  // --- Global Analytics ---
  public getAnalytics() {
    const activeUsersCount = Object.keys(this.data.users).length;
    const premiumUsersCount = Object.values(this.data.users).filter(u => u.subscription_type === 'PREMIUM').length;
    const totalSongs = Object.keys(this.data.tracks).length;
    const totalArtists = Object.keys(this.data.artists).length;
    const totalAlbums = Object.keys(this.data.albums).length;

    let totalPlays = 0;
    Object.values(this.data.tracks).forEach(t => totalPlays += t.plays);

    // Simple revenue model (pretend premium makes $9.99/month, and Razorpay/Stripe history simulation)
    const baseRevenue = premiumUsersCount * 9.99 + 49.99; // some dummy offset for show

    // Create play stats by genre for analytics charts
    const playByGenre: Record<string, number> = {};
    Object.values(this.data.tracks).forEach(t => {
      playByGenre[t.genre] = (playByGenre[t.genre] || 0) + t.plays;
    });

    return {
      totalUsers: activeUsersCount + 42, // offset with preloaded users for dashboard beauty
      activeUsers: activeUsersCount + 18,
      premiumUsers: premiumUsersCount + 12,
      revenue: Math.round(baseRevenue),
      totalSongs,
      totalArtists,
      totalAlbums,
      totalPlays: totalPlays + 42500,
      playByGenre
    };
  }
}

export const db = new LocalDatabase();
